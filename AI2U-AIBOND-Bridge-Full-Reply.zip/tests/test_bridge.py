"""Offline tests; execute with: py -m unittest discover -s tests -v"""
import importlib.util
import json
import pathlib
import sys
import unittest
from unittest.mock import patch

PROJECT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bridge_under_test', PROJECT / 'aibond_ai2u_final.py')
with patch.object(sys, 'argv', ['aibond_ai2u_final.py', '--mode', 'hardcore']):
    bridge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)


class BridgeTests(unittest.TestCase):
    def setUp(self):
        bridge.mood_state['anger'] = 0
        bridge.mood_state['turns'] = 0
        bridge.movement_step = 0
        self.fragments = [
            'Мозг в банке — это вообще-то для атмосферы,',
            'а не для супа,',
            'идиот. Готовить умею,',
            'но если ты ещё раз так пошутишь,',
            'ужин будет из тебя.',
        ]

    def snapshot(self, n):
        return {
            'markerVisible': True,
            'candidates': [
                {'text': line, 'score': 135 - i*3, 'depth': 4, 'index': i+1}
                for i, line in enumerate(self.fragments[:n])
            ],
        }

    def test_collect_all_five_bubbles_in_dom_order(self):
        snap = self.snapshot(5)
        # CDP score order may differ from DOM index order.
        snap['candidates'].reverse()
        joined = bridge.extract_cdp_reply(snap, 'BRIDGE-test', 'BRIDGE-test player text')
        self.assertEqual(joined, '\n'.join(self.fragments))

    def test_first_bubble_is_not_full_reply(self):
        self.assertEqual(bridge.extract_cdp_reply(self.snapshot(1), 'BRIDGE-test', 'msg'), self.fragments[0])

    def test_nested_duplicate_candidates_do_not_repeat_fragments(self):
        snap = self.snapshot(5)
        snap['candidates'] += [
            {'text': self.fragments[0], 'score': 170, 'depth': 2, 'index': 0},
            {'text': '\n'.join(self.fragments), 'score': 120, 'depth': 5, 'index': 1},
        ]
        joined = bridge.extract_cdp_reply(snap, 'BRIDGE-test', 'msg')
        self.assertEqual(joined, '\n'.join(self.fragments))

    def test_deny_alarm_popup(self):
        snap = {'markerVisible': True, 'candidates': [
            {'text': 'Установите будильник AI\nТип расписания\nВыражение Cron',
             'score': 200, 'depth': 4, 'index': 1},
        ]}
        self.assertEqual(bridge.extract_cdp_reply(snap, 'BRIDGE-test', 'msg'), '')

    def test_full_reply_drives_angry_face_and_not_smile(self):
        reply = bridge.extract_cdp_reply(self.snapshot(5), 'BRIDGE-test', 'msg')
        result = json.loads(bridge.format_for_ai2u(reply, json.dumps({
            'npc_location': 'lounge',
            'npc_action': 'standing',
            'player_location': 'lounge',
            'sentence_from_player': 'Мозг в банке — для супа?',
        }, ensure_ascii=False)))
        self.assertEqual(result['npc_reply_to_player'], '\n'.join(self.fragments))
        self.assertEqual(result['npc_face_expression'], 'angry_face')
        self.assertGreaterEqual(result['angry_emotion_value'], 30)

    def test_normal_remains_nonaggressive(self):
        bridge.MODE = 'normal'
        try:
            mood, expression, body, anger, _ = bridge.assess_mood('Добрый вечер! Как дела?', {})
            self.assertEqual(expression, 'slight_smile')
            self.assertEqual(anger, 0)
        finally:
            bridge.MODE = 'hardcore'


if __name__ == '__main__':
    unittest.main()


class TimingTests(unittest.TestCase):
    def test_waits_for_late_bubbles_instead_of_first_comma(self):
        # At t=0.0 first short bubble appears; additional bubbles are released
        # at 1-second intervals. The timer must not close at t=0.8.
        parts = [
            'Мозг в банке — это вообще-то для атмосферы,',
            'а не для супа,',
            'идиот. Готовить умею,',
            'но если ты ещё раз так пошутишь,',
            'ужин будет из тебя.',
        ]
        class Clock:
            current = 0.0
            def monotonic(self):
                return self.current
            def sleep(self, seconds):
                self.current += seconds
        clock = Clock()
        def snapshot(marker):
            n = min(5, int(clock.current // 1.0) + 1)
            return {
                'markerVisible': True, 'candidateCount': n,
                'candidates': [{'text': txt, 'score': 150-i, 'depth': 5, 'index': i}
                               for i, txt in enumerate(parts[:n])],
            }
        with patch.object(bridge.time, 'monotonic', clock.monotonic), \
             patch.object(bridge.time, 'sleep', clock.sleep), \
             patch.object(bridge, 'read_cdp_chat', snapshot):
            result = bridge._read_reply_until_ready('BRIDGE-test','prompt')
        self.assertEqual(result, '\n'.join(parts))
        self.assertGreaterEqual(clock.current, 6.0)

    def test_no_return_on_comma_within_fragment_window(self):
        # One incomplete clause receives a longer grace period.
        class Clock:
            current = 0.0
            def monotonic(self): return self.current
            def sleep(self, sec): self.current += sec
        clock = Clock()
        def snapshot(marker):
            return {'markerVisible': True, 'candidateCount': 1,
                    'candidates': [{'text': 'Начало фразы,', 'score': 120, 'depth': 3, 'index': 1}]}
        with patch.object(bridge.time, 'monotonic', clock.monotonic), \
             patch.object(bridge.time, 'sleep', clock.sleep), \
             patch.object(bridge, 'read_cdp_chat', snapshot):
            result = bridge._read_reply_until_ready('BRIDGE-test','prompt')
        self.assertEqual(result, 'Начало фразы,')
        self.assertGreaterEqual(clock.current, 6.0)
