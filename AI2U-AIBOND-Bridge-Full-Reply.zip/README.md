# AI2U ↔ AIBOND Bridge — multi-bubble reply / emotion fix

This experimental Windows bridge fixes two issues: **(1)** when AIBOND responds in multiple consecutive chat bubbles, the bridge now combines their text in order, instead of returning only the first bubble; **(2)** emotional analysis runs against the aggregated reply, so a later insult or threat can trigger an angry NPC face rather than a smile.

## Changes

- CDP-based send/receive; no pywinauto UI reading.
- Read up to 40 nearby sibling message nodes after the unique outgoing marker; deduplicate nested candidates, preserve DOM order, and reject modal/menu content.
- Aggregate text before computing `angry_emotion_value`, `npc_face_expression`, and body animation.
- Poll every 0.1 seconds, require 0.8 seconds of unchanged text, and wait 2.25 seconds for additional reply bubbles after the most recent update. A dangling comma, colon or dash gets up to 6 seconds.
- Keep Normal/Hardcore modes, NPC-follow behavior and duplicate-request caching.
- Added `[FRAGMENTS]` logs and offline tests for the reported five-part reply.

## Run

1. Back up and replace the previous `aibond_ai2u_final.py`. If your old CMD launchers pass `--poll-interval 0.9`, replace them too.
2. Start AIBOND via `she-steam.exe --remote-debugging-port=9222` and open the main character chat.
3. Install requirements if needed: `py -m pip install -r requirements.txt`.
4. Run `start_normal.cmd` or `start_hardcore.cmd`.
5. In AI2U custom endpoint settings (F9), set: Base URL `http://127.0.0.1:8765/v1`, model `aibond`, key `local`, streaming OFF.

For longer pauses between messages, use:

```powershell
py .\aibond_ai2u_final.py --mode hardcore --quiet-seconds 0.8 --fragment-gap-seconds 3.5 --poll-interval 0.1
```

**Limitations:** This is a DOM heuristic, not an official AIBOND API. If AIBOND pauses longer than the bubble-gap timeout between complete sentences, it can still truncate; increasing that timeout trades latency for completeness. Anger is an estimate based on text, not AIBOND's private internal state; AI2U/mod can reject facial expressions/animations. CDP port 9222 must stay local; never expose to untrusted networks.

Run tests with `py -m unittest discover -s tests -v`. Tests pass on synthetic snapshots, but the latest version is **not yet end-to-end verified with your live AIBOND**.

Unofficial community project, MIT License (2026 Caurys).
