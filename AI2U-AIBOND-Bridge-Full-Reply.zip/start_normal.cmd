@echo off
chcp 65001 >nul
py "%~dp0aibond_ai2u_final.py" --mode normal --quiet-seconds 0.8 --fragment-gap-seconds 2.25 --poll-interval 0.1
pause
